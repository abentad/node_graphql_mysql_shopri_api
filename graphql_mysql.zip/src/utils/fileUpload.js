const singleFileUpload = (file) =>{

};

module.exports = { singleFileUpload };