const parseJson = (json) =>{
    return JSON.parse(JSON.stringify(json));
}

module.exports = parseJson;